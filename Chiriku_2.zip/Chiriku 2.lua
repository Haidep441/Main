loadstring(game:HttpGet(("https://raw.githubusercontent.com/daucobonhi/Ui-Redz-V2/refs/heads/main/UiREDzV2.lua")))()

       local Window = MakeWindow({
         Hub = {
         Title = "Tổng Hợp Script",
         Animation = "Script by haidepzai"
         },
        Key = {
        KeySystem = false,
        Title = "Key System",
        Description = "",
        KeyLink = "",
        Keys = {"1234"},
        Notifi = {
        Notifications = true,
        CorrectKey = "Running the Script...",
       Incorrectkey = "The key is incorrect",
       CopyKeyLink = "Copied to Clipboard"
      }
    }
  })

       MinimizeButton({
       Image = "http://www.roblox.com/asset/?id=129971264725842",
       Size = {60, 60},
       Color = Color3.fromRGB(10, 10, 10),
       Corner = true,
       Stroke = false,
       StrokeColor = Color3.fromRGB(255, 0, 0)
      })
      
------ Tab
     local Tab1o = MakeTab({Name = "Script Farm"})
     local Tab2o = MakeTab({Name = "Script Kaitun"})
     local Tab3o = MakeTab({Name = "Script Fix Lag"})
     local Tab4o = MakeTab({Name = "Script Tổng Hợp"})
     
------- BUTTON
    
    AddButton(Tab1o, {
     Name = "Banana Hub",
    Callback = function()
	  repeat wait() until game:IsLoaded() and game.Players.LocalPlayer getgenv().Key = "Key" loadstring(game:HttpGet("https://raw.githubusercontent.com/obiiyeuem/vthangsitink/main/BananaHub.lua"))()
  end
  })
  
  AddButton(Tab1o, {
     Name = "Maru Hub Hub",
    Callback = function()
	  loadstring(game:HttpGet("https://raw.githubusercontent.com/YUKE000/BloxFruit/refs/heads/main/MARU-HUB-CRACKED-V2.0"))()
  end
  })
  
  AddButton(Tab1o, {
     Name = "Hoho Hub",
    Callback = function()
      loadstring(game:HttpGet("https://raw.githubusercontent.com/acsu123/HOHO_H/main/Loading_UI"))()
  end
  })
  
  AddButton(Tab1o, {
     Name = "Xero Hub",
    Callback = function()
	  getgenv().Team = "Marines"

getgenv().Hide_Menu = false

getgenv().Auto_Execute = false

loadstring(game:HttpGet("https://raw.githubusercontent.com/Xero2409/XeroHub/refs/heads/main/main.lua"))()
  end
  })
  
  AddButton(Tab1o, {
     Name = "Redz Hub",
    Callback = function()
	  local Settings = {
  JoinTeam = "Pirates"; -- Pirates/Marines
  Translator = true; -- true/false
}

loadstring(game:HttpGet("https://raw.githubusercontent.com/realredz/BloxFruits/refs/heads/main/Source.lua"))(Settings)
  end
  })
  
  AddButton(Tab1o, {
     Name = "W-azure Hub",
    Callback = function()
	  loadstring(game:HttpGet("https://api.luarmor.net/files/v3/loaders/3b2169cf53bc6104dabe8e19562e5cc2.lua"))()
  end
  })
  
  AddButton(Tab1o, {
     Name = "Andepzai Hub",
    Callback = function()
	  loadstring(game:HttpGet("https://raw.githubusercontent.com/AnDepZaiHub/AnDepZaiHubBeta/refs/heads/main/AnDepZaiHubNewUpdated.lua"))()
  end
  })
  
  AddButton(Tab1o, {
     Name = "Tsuo Hub",
    Callback = function()
	  loadstring(game:HttpGet("https://raw.githubusercontent.com/Tsuo7/TsuoHub/main/Tsuoscripts"))()
  end
  })
  
  AddButton(Tab1o, {
     Name = "Astral Hub",
    Callback = function()
	  loadstring(game:HttpGet("https://raw.githubusercontent.com/Overgustx2/Main/refs/heads/main/BloxFruits_25.html"))()
  end
  })
  
  AddButton(Tab1o, {
     Name = "Turbolite Hub",
    Callback = function()
	  loadstring(game:HttpGet("https://raw.githubusercontent.com/TurboLite/Script/refs/heads/main/Main.lua"))()
  end
  })
  
  AddButton(Tab1o, {
     Name = "Ak Gaming Hub",
    Callback = function()
	  loadstring(game:HttpGet("https://raw.githubusercontent.com/binh99999yeuem/ak-gaming/refs/heads/main/ak%20gaming.txt"))()
  end
  })
  
  AddButton(Tab1o, {
     Name = "Rubu V3 Hub",
    Callback = function()
	  loadstring(game:HttpGet("https://raw.githubusercontent.com/LuaCrack/RubuRoblox/refs/heads/main/RubuBF"))()
  end
  })
  
  AddButton(Tab1o, {
     Name = "Doremon Hub",
    Callback = function()
	  loadstring(game:HttpGet("https://raw.githubusercontent.com/obfmoonsec/Masterhub/refs/heads/main/obf"))()
  end
  })
  
  AddButton(Tab1o, {
     Name = "Zis Roblox Hub",
    Callback = function()
	  loadstring(game:HttpGet("https://raw.githubusercontent.com/LuaCrack/Zis/refs/heads/main/ZisRb3"))()
  end
  })
  
  AddButton(Tab1o, {
     Name = "Hiru Hub",
    Callback = function()
	  loadstring(game:HttpGet("https://raw.githubusercontent.com/NGUYENVUDUY1/Dev-Hiru/refs/heads/main/HiruHub.lua"))()
  end
  })
  
  AddButton(Tab1o, {
     Name = "Vxeze Hub",
    Callback = function()
	  loadstring(game:HttpGet("https://raw.githubusercontent.com/Dex-Bear/VxezeHubHopBoss/refs/heads/main/SkidConCacBaM"))()
  end
  })
  
  AddButton(Tab1o, {
     Name = "Quantum Hub",
    Callback = function()
	  loadstring(game:HttpGet("https://raw.githubusercontent.com/Trustmenotcondom/QTONYX/refs/heads/main/QuantumOnyx.lua"))()
  end
  })
  
  AddButton(Tab1o, {
     Name = "BapRed Hub",
    Callback = function()
	  loadstring(game:HttpGet("https://raw.githubusercontent.com/LuaCrack/BapRed/main/BapRedHub"))()
  end
  })
  
  AddButton(Tab1o, {
     Name = "BlueX Hub",
    Callback = function()
	  loadstring(game:HttpGet("https://raw.githubusercontent.com/Dev-BlueX/BlueX-Hub/refs/heads/main/EN.lua"))()
  end
  })
  
  AddButton(Tab1o, {
     Name = "Min Gaming Hub",
    Callback = function()
	  loadstring(game:HttpGet("https://raw.githubusercontent.com/LuaCrack/Min/refs/heads/main/MinSeHubVn"))()
  end
  })
  
  AddButton(Tab1o, {
     Name = "Ganteng Hub",
    Callback = function()
	  loadstring(game:HttpGet("https://api.luarmor.net/files/v3/loaders/516a5669fc39b4945cd0609a08264505.lua"))()"))()
  end
  })
  
  AddButton(Tab1o, {
     Name = "Cokka Hub",
    Callback = function()
	  loadstring(game:HttpGet("https://raw.githubusercontent.com/UserDevEthical/Loadstring/main/CokkaHub.lua"))()
  end
  })
  
  AddButton(Tab1o, {
     Name = "Văn Thành Hub",
    Callback = function()
	  loadstring(game:HttpGet("https://raw.githubusercontent.com/VanThanhIOS/OniiChanVanThanhIOS/refs/heads/main/VanThanhIOS2027Online"))()
  end
  })
  
  AddButton(Tab2o, {
     Name = "Kaitun Banana Hub",
    Callback = function()
	  repeat wait() until game:IsLoaded() and game.Players.LocalPlayer

getgenv().Key = "dán key vào đây nhé"

getgenv().SettingFarm ={

    ["Hide UI"] = false,

    ["Reset Teleport"] = {

        ["Enabled"] = false,

        ["Delay Reset"] = 3,

        ["Item Dont Reset"] = {

            ["Fruit"] = {

                ["Enabled"] = true,

                ["All Fruit"] = true, 

                ["Select Fruit"] = {

                    ["Enabled"] = false,

                    ["Fruit"] = {},

                },

            },

        },

    },

    ["Get Items"] = {

        ["Godhuman"] = true,

        ["Mirror Fractal"] = true,

        ["Cursed Dual Katana"] = true,

    },

    ["Select Hop"] = { -- 70% will have it

        ["Hop Find Rip Indra Get Valkyrie Helm or Get Tushita"] = true, 

        ["Hop Find Dough King Get Mirror Fractal"] = false,

        ["Hop Find Raids Castle [CDK]"] = true,

        ["Hop Find Cake Queen [CDK]"] = true,

        ["Hop Find Soul Reaper [CDK]"] = true,

    },

    ["Buy Haki"] = {

        ["Enhancement"] = false,

        ["Skyjump"] = true,

        ["Flash Step"] = true,

        ["Observation"] = true,

    },

    ["Lock Fruit"] = {},

    ["Webhook"] = {

        ["Enabled"] = false,

        ["WebhookUrl"] = "",

    }

}

 

 

loadstring(game:HttpGet("https://raw.githubusercontent.com/obiiyeuem/vthangsitink/main/BananaCat-kaitunBF.lua"))()
  end
  })
  
  AddButton(Tab2o, {
     Name = "Kaitun Xero Hub",
    Callback = function()
	  -- Max level, godhuman, cdk, sgt
script_key = "" -- premium only, u can leave it blank if ur not
getgenv().Shutdown = false -- Turn on if u are farming bulk accounts
getgenv().Configs = {
    ["Team"] = "Pirates",
    ["Gun Farm"] = false, -- Fast farm level, but farming melee is slow
    ["FPS Boost"] = {
        ["Enable"] = false,
        ["FPS Cap"] = 120,
    },
    ["Farm Boss Drops"] = {
        ["Enable"] = false,
        ["When x2 Exp Expired"] = false
    },
    ["Hop"] = {
        ["Enable"] = false,
        ["Hop Find Tushita"] = true
    },
    ["Auto Collect Berry"] = false,
    ["Auto Evo Race"] = true,
    ["Awaken Fruit"] = false,
    ["Rainbow Haki"] = true,
    ["Hop Player Near"] = false,
    ["Skull Guitar"] = true,
    ["Find Fruit"] = false, -- Will find 1m+ fruit to unlock swan door to access third sea
    ["Cursed Dual Katana"] = true,
    ["Switch Melee"] = true,
    ["Eat Fruit"] = "", -- leave blank for none, put the fruit name like this example: Smoke Fruit, T-Rex Fruit, ...
    ["Snipe Fruit"] = "", -- leave blank for none, put the fruit name like this example: Smoke Fruit, T-Rex Fruit, ...
    ["Lock Fragment"] = 0,
    ["Buy Stuffs"] = true -- buso, geppo, soru, ken haki, ...
}
repeat task.wait() pcall(function() loadstring(game:HttpGet("https://raw.githubusercontent.com/Xero2409/XeroHub/refs/heads/main/kaitun.lua"))() end) until getgenv().Check_Execute
  end
  })
  
  AddButton(Tab2o, {
     Name = "Kaitun Maru Hub",
    Callback = function()
	  getgenv().Key = "MARU-MQ3ZL-S7C2P-434O-55XR-WA51"

getgenv().id = "1128597911761076296"

getgenv().Script_Mode = "Kaitun_Script"

loadstring(game:HttpGet("https://raw.githubusercontent.com/xshiba/MaruBitkub/main/Mobile.lua"))()
  end
  })
  
  AddButton(Tab2o, {
     Name = "Kaitun Rise Hub",
    Callback = function()
	  _G.Config = {

    ["Melee"] = {

        ["Superhuman"] = true,

        ["Death Step"] = true,

        ["Sharkman Karate"] = true,

        ["Electric Claw"] = true,

        ["Dragon Talon"] = true,

        ["Godhuman"] = true

    },

    ["Sword"] = {

        ["Saber"] = true,

        ["Rengoku"] = true,

        ["Canvander"] = true,

        ["Buddy Sword"] = true,

        ["Yama"] = true,

        ["Tushita"] = true,

        ["True Triple Katana"] = true,

        ["Cursed Dual Katana"] = true

    },

    ["Gun"] = {

        ["Kabucha"] = true,

        ["Acidum Rifle"] = true,

        ["Serpent Bow"] = true

    },

    ["Mastery"] = {

        ["Sword"] = true

    },

    ["Setting"] = {

        ["Enabled"] = true,

        ["Bring Mob [Less Lag]"] = true,

        ["Hop Server"] = true,

        ["Reduce Lag"] = true,

        ["Notifycation Remove"] = true,

        ["Hop When Player Nearby"] = {

            ["Enabled"] = true,

            ["Radius"] = 350

        }

    }

}

loadstring(game:HttpGet("https://raw.githubusercontent.com/TrashLua/BloxFruits/main/KaitunBeta.RiseEvo"))()
  end
  })
  
  AddButton(Tab2o, {
     Name = "Kaitun Simple Hub",
    Callback = function()
	  getgenv().Team = "Pirates"
getgenv().simple_settings = {



    ["MASTERY"] = { -- Settings related to leveling up weapon or skill mastery



        ["ACTIVE"] = true, -- Enable or disable mastery leveling (true = enabled, false = disabled)



        ["METHOD"] = "Half", -- Method for gaining mastery, "Half"[300] or "Full"[600]



    },



 



    ["OBJECTIVE"] = { -- Goals for farming and unlocking features



        ["GODHUMAN"] = true, -- Automatically unlock the "Godhuman" fighting style



        ["RACE-V3"] = true, -- Automatically upgrade character race to V3 if possible Human, Mink, (Fishman, Ghoul, Cyborg) soon



        ["FRAGMENT"] = 100000, -- Limit number of fragments to collect



 



        -- SWORD



        ["CANVANDER"] = true,



        ["BUDDY-SWORD"] = true,



        ["CURSED-DUAL-KATANA"] = true,



        ["SHARK-ANCHOR"] = true, -- soon..



 



        --GUN



        ["ACIDUM-RIFLE"] = true,



        ["VENOM-BOW"] = true,



        ["SOUL-GUITAR"] = true,



    },



 



    ["FRUITPURCHASE"] = false, -- Automatically purchase fruits based on priority list



    ["PRIORITYFRUIT"] = { -- List of preferred fruits to purchase or eat in order of priority



        [1] = "Dragon-Dragon",



        [2] = "Flame-Flame",



        [3] = "Rumble-Rumble",



        [4] = "Human-Human: Buddha",



        [5] = "Dark-Dark",



    },



 



    ["FPSCAP"] = 120, -- Limit the frame rate to optimize performance



    ["LOWTEXTURE"] = true -- Reduce graphic quality for better performance



}



loadstring(game:HttpGet("https://raw.githubusercontent.com/simple-hubs/contents/refs/heads/main/bloxfruit-kaitan-main.lua"))()
  end
  })
  
  AddButton(Tab3o, {
     Name = "Fix Lag Turbolite Hub",
    Callback = function()
	  loadstring(game:HttpGet("https://raw.githubusercontent.com/TurboLite/Script/main/FixLag.lua"))()
  end
  })
  
  AddButton(Tab4o, {
     Name = " Starlight Tổng Hợp Script",
    Callback = function()
	  loadstring(game:HttpGet("https://raw.githubusercontent.com/YumCoding-Alt/StarlightHub/refs/heads/main/SkidConCacBaMay.txt"))()
  end
  })
